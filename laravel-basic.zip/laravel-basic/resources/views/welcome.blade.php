{{--
<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
    </head>
    <body>

    </body>
</html>
--}}
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

@extends('layouts.master')

@section('title')
        welcome!!!!
@endsection


@section('content')
    @include('components.share', ['url' => 'http://vivacious.co.in/'])
        @include('includes.message-block')
    <script src="https://code.jquery.com/jquery-2.2.0.min.js"></script>
    <script>

        var popupSize = {
            width: 780,
            height: 550
        };

        $(document).on('click', '.social-buttons > a', function(e){

            var
                    verticalPos = Math.floor(($(window).width() - popupSize.width) / 2),
                    horisontalPos = Math.floor(($(window).height() - popupSize.height) / 2);

            var popup = window.open($(this).prop('href'), 'social',
                    'width='+popupSize.width+',height='+popupSize.height+
                    ',left='+verticalPos+',top='+horisontalPos+
                    ',location=0,menubar=0,toolbar=0,status=0,scrollbars=1,resizable=1');

            if (popup) {
                popup.focus();
                e.preventDefault();
            }

        });
    </script>
    <div class="cotn_principal">
        <div class="cont_centrar">

            <div class="cont_login">
                <div class="cont_info_log_sign_up">
                    <div class="col_md_login">
                        <div class="cont_ba_opcitiy">

                            <h2>LOGIN</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            <button class="btn_login" onclick="cambiar_login()">LOGIN</button>
                        </div>
                    </div>
                    <div class="col_md_sign_up">
                        <div class="cont_ba_opcitiy">
                            <h2>SIGN UP</h2>


                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

                            <button class="btn_sign_up" onclick="cambiar_sign_up()">SIGN UP</button>
                        </div>
                    </div>
                </div>


                <div class="cont_back_info">
                    <div class="cont_img_back_grey">
                        <img src="https://images.unsplash.com/42/U7Fc1sy5SCUDIu4tlJY3_NY_by_PhilippHenzler_philmotion.de.jpg?ixlib=rb-0.3.5&q=50&fm=jpg&crop=entropy&s=7686972873678f32efaf2cd79671673d" alt="" />
                    </div>

                </div>
                <div class="cont_forms">
                    <div class="cont_img_back_">
                        <img src="https://images.unsplash.com/42/U7Fc1sy5SCUDIu4tlJY3_NY_by_PhilippHenzler_philmotion.de.jpg?ixlib=rb-0.3.5&q=50&fm=jpg&crop=entropy&s=7686972873678f32efaf2cd79671673d" alt="" />
                    </div>
                    <div class="cont_form_login">
                        <a href="#" onclick="ocultar_login_sign_up()"><i class="material-icons">&#xE5C4;</i></a>
                        <h2>LOGIN</h2>
                        <input type="text" placeholder="Email" />
                        <input type="password" placeholder="Password" />
                        <button class="btn_login" onclick="cambiar_login()">LOGIN</button>
                    </div>

                    <div class="cont_form_sign_up">
                        <a href="#" onclick="ocultar_login_sign_up()"><i class="material-icons">&#xE5C4;</i></a>
                        <h2>SIGN UP</h2>
                        <input type="text" placeholder="Email" />
                        <input type="text" placeholder="User" />
                        <input type="password" placeholder="Password" />
                        <input type="password" placeholder="Confirm Password" />
                        <button class="btn_sign_up" onclick="cambiar_sign_up()">SIGN UP</button>

                    </div>

                </div>

            </div>
        </div>
    </div>
    {{--<div class="row">
      <div class="col-md-6">
          <form action="{{ route('signup')}}" method="post">
              <div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">
                  <h3>Sign Up</h3>
                  <label for="email">Your E-Mail</label>
                  <input class="form-control" type="text" name="email" id="email" value="{{ Request::old('email') }}" >
              </div>
              <div class="form-group {{ $errors->has('first_name') ? 'has-error' : '' }}">
                  <label for="first_name">Your First Name</label>
                  <input class="form-control" type="text" name="first_name" id="first_name" value="{{ Request::old('first_name') }}" >
              </div>
              <div class="form-group {{ $errors->has('password') ? 'has-error' : '' }}">
                  <label for="password">Your Password</label>
                  <input class="form-control" type="password" name="password" id="password" value="{{ Request::old('password') }}" >
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
              <input type="hidden" name="_token" value="{{ Session::token() }}">
          </form>
      </div>

        <div class="col-md-6">
            <form action="{{ route('signin') }}" method="post">
                <div class="form-group">
                    <h3>Sign In</h3>
                    <label for="email">Your E-Mail</label>
                    <input class="form-control" type="text" name="email" id="email" value="{{ Request::old('email') }}" >
                </div>

                <div class="form-group">
                    <label for="password">Your Password</label>
                    <input class="form-control" type="password" name="password" id="password" value="{{ Request::old('password') }}" >
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                <input type="hidden" name="_token" value="{{ Session::token() }}">
            </form>
        </div>

    </div>
--}}@endsection