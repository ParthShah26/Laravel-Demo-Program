<div class="social-buttons">

    <a class="btn btn-block btn-social btn-facebook"  href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode($url)); ?>"
       target="_blank">
        <span class="fa fa-facebook" style="width: 200px;">&nbspFacebook</span>
    </a>

</div>